<?php

namespace App\Livewire;

use Livewire\Component;

class ScanRFID extends Component
{
    public function render()
    {
        return view('livewire.scan-r-f-i-d');
    }
}
