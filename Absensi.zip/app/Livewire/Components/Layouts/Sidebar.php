<?php

namespace App\Livewire\Components\Layouts;

use Livewire\Component;

class Sidebar extends Component
{
    public function render()
    {
        return view('livewire.components.layouts.sidebar');
    }
}
